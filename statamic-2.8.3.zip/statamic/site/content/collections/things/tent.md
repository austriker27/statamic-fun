title: Tent
id: 7843a532-fab4-48f9-b2d6-2a1a85fe5561
amazon_id: B00KGNR7CK
photo: http://ecx.images-amazon.com/images/I/51MZOStw4%2BL.jpg
