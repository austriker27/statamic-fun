<?php

namespace Statamic\Addons\Select;

use Statamic\Extend\Fieldtype;

class SelectFieldtype extends Fieldtype
{
}
