<?php

namespace Statamic\Addons\Checkboxes;

use Statamic\Extend\Fieldtype;

class CheckboxesFieldtype extends Fieldtype
{
}
