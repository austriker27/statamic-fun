<?php

namespace Statamic\Addons\Textarea;

use Statamic\Extend\Fieldtype;

class TextareaFieldtype extends Fieldtype
{
}
