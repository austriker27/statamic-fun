<?php

namespace Statamic\Addons\Fieldset;

use Statamic\Extend\Fieldtype;

class FieldsetFieldtype extends Fieldtype
{
}
