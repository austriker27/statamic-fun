<?php

namespace Statamic\Addons\Hidden;

use Statamic\Extend\Fieldtype;

class HiddenFieldtype extends Fieldtype
{
}
