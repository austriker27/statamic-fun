<?php

namespace Statamic\Addons\Markdown;

use Statamic\Extend\Fieldtype;

class MarkdownFieldtype extends Fieldtype
{
}
