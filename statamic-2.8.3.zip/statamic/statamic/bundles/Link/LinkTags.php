<?php

namespace Statamic\Addons\Link;

use Statamic\Addons\Path\PathTags;

class LinkTags extends PathTags
{
}
