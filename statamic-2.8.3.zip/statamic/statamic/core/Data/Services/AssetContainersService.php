<?php

namespace Statamic\Data\Services;

class AssetContainersService extends BaseService
{
    /**
     * The repo key
     * 
     * @var string
     */
    protected $repo = 'assetcontainers';
}