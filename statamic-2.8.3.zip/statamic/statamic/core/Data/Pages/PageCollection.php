<?php

namespace Statamic\Data\Pages;

use Statamic\Data\Content\ContentCollection;

class PageCollection extends ContentCollection
{

}
